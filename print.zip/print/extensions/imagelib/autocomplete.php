 <?php
  $con = mysql_connect('localhost','clorida1_premium','GD6W=(5@iIc1','clorida1_premiumprint');
       mysql_select_db("clorida1_premiumprint");
     $term=$_GET["term"];
     $query=mysql_query("SELECT DISTINCT thumbnail_template_name, id FROM xmr_fabric_clipart where thumbnail_template_name like '%".$term."%' order by thumbnail_template_name ");
     $json=array();
        while($clipart=mysql_fetch_array($query)){
             $json[]=array(
                        'value'=> $clipart["thumbnail_template_name"],
                        'label'=>$clipart["thumbnail_template_name"]." - ".$clipart["id"]
                            );
        }
        if(isset($_POST['ind_id']))
        {
            $ind_id=$_POST['ind_id'];
            $getind=mysql_query("SELECT * from xmr_fabric_clipart where category_id='".$ind_id."'");
            while($get_ind=mysql_fetch_array($getind))
            {
                    $tempname=$get_ind['thumbnail_template_name'];
            }
        }
     
     echo json_encode($json);
     
    ?>